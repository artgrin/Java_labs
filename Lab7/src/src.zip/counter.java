
public interface counter {
	int count(int x);
}
