
public interface tostr {
	String convert(int x);
}
